import { Component, h, State } from '@stencil/core';

@Component({
  tag: 'lista-tareas-component',
  styleUrl: 'lista-tareas-component.css',
  shadow: true,
})
export class ListaTareasComponent {
  @State() tareas: { texto: string; completada: boolean }[] = [];
  private nuevaTarea: string = '';

  manejarCambio(event: Event) {
    this.nuevaTarea = (event.target as HTMLInputElement).value;
  }

  agregarTarea() {
    if (this.nuevaTarea.trim() !== '') {
      this.tareas = [...this.tareas, { texto: this.nuevaTarea, completada: false }];
      this.nuevaTarea = ''; // Limpiar input
    }
  }

  eliminarTarea(index: number) {
    this.tareas = this.tareas.filter((_, i) => i !== index);
  }

  marcarCompletada(index: number) {
    this.tareas = this.tareas.map((tarea, i) =>
      i === index ? { ...tarea, completada: !tarea.completada } : tarea
    );
  }

  render() {
    return (
      <div class="contenedor">
        <h1>📌 Lista de Tareas</h1>
        <div class="entrada">
          <input type="text" placeholder="Nueva tarea..." onInput={(e) => this.manejarCambio(e)} />
          <button onClick={() => this.agregarTarea()}>➕ Agregar</button>
        </div>
        <ul>
          {this.tareas.map((tarea, index) => (
            <li class={tarea.completada ? 'completada' : ''}>
              <span onClick={() => this.marcarCompletada(index)}>{tarea.texto}</span>
              <button onClick={() => this.eliminarTarea(index)}>❌</button>
            </li>
          ))}
        </ul>
      </div>
    );
  }
}
