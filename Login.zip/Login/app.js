const { createApp } = Vue;

createApp({
  data() {
    return {
      usuarioLogueado: localStorage.getItem("usuarioLogueado") === "true",
      servicios: {
        "PEINADOS": [
          { nombre: "Trenzas medianas con rizos", imagen: "img/peinado1.jpg", descripcion: "trenzas con estilo doble.", precio: 100000 },
          { nombre: "Trenzas largas con estilo fulani", imagen: "img/peinado2.jpg", descripcion: "trenzas fulanis con rizos.", precio: 150000 },
          { nombre: "Cola alta mediana", imagen: "img/peinado3.jpg", descripcion: "Cola alta de extension mediana, con aplastado.", precio: 70000 },
          { nombre: "Puesta de extensión", imagen: "img/peinado4.jpg", descripcion: "Puesta de extension con estilo sencillo.", precio: 100000 },
          { nombre: "Puesta de peluca", imagen: "img/peinado5.jpg", descripcion: "Puesta de peluca con frontal, efecto natural.", precio: 75000 },
          { nombre: "Definicion de rizos", imagen: "img/peinado7.jpg", descripcion: "Definimos tus hermosos rizos con productos de primera calidad y el estilo de tu preferencia.", precio: 75000 },
          { nombre: "Trenzas sueltas", imagen: "img/peinado8.jpg", descripcion: "Trenzas largas alimentadas de kanekalon.", precio: 95000 },
          { nombre: "Trenzas francesas", imagen: "img/peinado 9.jpg", descripcion: "Trenzas largas con la puntas rubias, sueltas y ondulada.", precio: 75000 },
          { nombre: "Crespos puntas rubias a crochet", imagen: "img/peinados10.jpg", descripcion: "Puesta rizos a crochet.", precio: 180000 },
          { nombre: "crespos con crochet", imagen: "img/peinado11.jpg", descripcion: "Puesta de rizos a crochet, efecto natural.", precio: 180000 }
        ],
        "MAQUILLAJE": [
          { nombre: "Maquillaje glam", imagen: "img/maquillaje1.jpg", descripcion: "Maquillaje en tonos tierra ideal para eventos y matrimonios.", precio: 90000 },
          { nombre: "Maquillaje Social", imagen: "img/maquillaje2.jpg", descripcion: "Maquillaje natural para eventos y reuniones.", precio: 95000 },
          { nombre: "Maquillaje Social", imagen: "img/maquillaje3.jpg", descripcion: "Maquillaje natural para eventos y reuniones.", precio: 80000 },
          { nombre: "Maquillaje Social", imagen: "img/maquillaje4.jpg", descripcion: "Maquillaje natural para eventos y reuniones.", precio: 90000 },
          { nombre: "Maquillaje Social", imagen: "img/maquillaje5.jpg", descripcion: "Maquillaje natural para eventos y reuniones.", precio: 95000 },
          { nombre: "Maquillaje Social", imagen: "img/maquillaje6.jpg", descripcion: "Maquillaje natural para eventos y reuniones.", precio: 60000 },
          { nombre: "Maquillaje Social", imagen: "img/maquillaje7.jpg", descripcion: "Maquillaje natural para eventos y reuniones.", precio: 75000 },
          { nombre: "Maquillaje Social", imagen: "img/maquillaje8.jpg", descripcion: "Maquillaje natural para eventos y reuniones.", precio: 65000 }
        ],
        "UÑAS": [
          { nombre: "Acrílicas largas", imagen: "img/acrilicas1.jpg", descripcion: "Uñas acrílicas largas con acabado cuadrado y elegante.", precio: 120000 },
          { nombre: "Acrílicas cortas", imagen: "img/acrilicas2.jpg", descripcion: "Uñas acrílicas cortas con un diseño clásico y sofisticado.", precio: 120000 },
          { nombre: "Acrílicas almendradas", imagen: "img/acrilicas3.jpg", descripcion: "Forma almendrada que brinda un toque moderno y delicado.", precio: 130000 },
          { nombre: "Acrílicas con decorado", imagen: "img/acrilicas4.jpg", descripcion: "Diseño personalizado con detalles artísticos y piedras decorativas.", precio: 150000 },
          { nombre: "Press On naturales", imagen: "img/presson1.jpg", descripcion: "Uñas adhesivas de aspecto natural, listas para usar.", precio: 85000 },
          { nombre: "Press On decoradas", imagen: "img/presson2.jpg", descripcion: "Uñas adhesivas con diseños vibrantes y modernos.", precio: 85000 },
          { nombre: "Esmaltado semipermanente", imagen: "img/semipermanente.jpg", descripcion: "Durabilidad y brillo intenso con esmalte semipermanente.", precio: 65000 },
          { nombre: "Pedicure clásico", imagen: "img/pedicure1.jpg", descripcion: "Cuidado esencial para los pies con hidratación y esmaltado.", precio: 55000 },
          { nombre: "Pedicure spa", imagen: "img/pedicure2.jpg", descripcion: "Tratamiento relajante con exfoliación y masaje.", precio: 60000 },
          { nombre: "Pedicure deluxe", imagen: "img/pedicure3.jpg", descripcion: "Cuidado completo con mascarilla, masaje y acabado profesional.", precio: 45000 }
        ],
        "CEJAS": [
          { nombre: "Cejas con Henna", imagen: "img/cejas6.jpg", descripcion: "Definición temporal con henna para realzar la forma natural de tus cejas.", precio: 30000 },
          { nombre: "Diseño de Cejas Clásico", imagen: "img/cejas2.jpg", descripcion: "Moldeado profesional para una forma armoniosa y bien definida.", precio: 100000 },
          { nombre: "Diseño de Cejas Natural", imagen: "img/cejas1.jpg", descripcion: "Moldeado sutil para conservar el aspecto natural de las cejas.", precio: 90000 },
          { nombre: "Diseño de Cejas con Depilación", imagen: "img/cejas3.jpg", descripcion: "Moldeado profesional con depilación para una apariencia limpia y pulida.", precio: 80000 },
          { nombre: "Diseño de Cejas con Hilo", imagen: "img/cejas4.jpg", descripcion: "Definición precisa utilizando la técnica de depilación con hilo.", precio: 85000 },
          { nombre: "Diseño de Cejas con Pinza", imagen: "img/cejas5.jpg", descripcion: "Moldeado manual para un acabado meticuloso y detallado.", precio: 75000 },
          { nombre: "Diseño de Cejas con Tintura", imagen: "img/cejas7.jpg", descripcion: "Realza el color y la forma de tus cejas con una tintura especializada.", precio: 65000 }
        ],
        "PESTAÑAS": [
          { nombre: "Extensiones pelo a pelo", imagen: "img/pestaña1.jpg", descripcion: "Luce una mirada naturalmente linda.", precio: 100000 },
          { nombre: "Extensiones volumen normal", imagen: "img/pestaña2.jpg", descripcion: "sigue luciendo natural, realzando tu mirada.", precio: 120000 },
          { nombre: "Extensiones pelo a pelo", imagen: "img/pestaña3.jpg", descripcion: "Efecto lagrima, ideales para gustos sutiles pero profundos.", precio: 100000 },
          { nombre: "Efecto ojo de gato", imagen: "img/pestaña4.jpg", descripcion: "Mayor densidad.", precio: 150000 },
          { nombre: "Volumen ruso", imagen: "img/pestaña5.jpg", descripcion: "Mayor densidad y volumen.", precio: 135000 }
        ]
      },
      currentSlide: {
        "PEINADOS": 0,
        "MAQUILLAJE": 0,
        "UÑAS": 0,
        "CEJAS": 0,
        "PESTAÑAS": 0
      },
      cita: {
        servicio: '',
        fecha: '',
        hora: ''
      },
      
      seleccionados: [],
      total: 0,
      pago: {
        nombre: '',
        email: '',
        metodo: ''
      }
    };
  },
  methods: {
    realizarPago() {
      if (!this.usuarioLogueado) {
        Swal.fire({
          icon: 'warning',
          title: 'Debes iniciar sesión',
          text: 'Por favor inicia sesión para poder realizar el pago.',
          confirmButtonText: 'Ir al login'
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.href = './login.php';
          }
        });
        return;
      }

      Swal.fire({
        icon: 'success',
        title: 'Pago realizado',
        text: 'Gracias por tu compra. ¡Te esperamos!'
      });

      this.pago = { nombre: '', email: '', metodo: '' };
      this.seleccionados = [];
      this.total = 0;
    },
    confirmarCita() {
      if (this.cita.servicio && this.cita.fecha && this.cita.hora) {
        this.sumarPuntos();
        Swal.fire(
          "¡Cita agendada!",
          `Servicio: ${this.cita.servicio}\nFecha: ${this.cita.fecha} a las ${this.cita.hora}`,
          "success"
        );
      } else {
        Swal.fire("Faltan datos", "Por favor completa todos los campos.", "warning");
      }
    },
    cerrarSesion() {
      localStorage.removeItem("usuarioLogueado");
      localStorage.removeItem("puntos");
      Swal.fire('Sesión cerrada', 'Vuelve pronto', 'info').then(() => {
        window.location.href = './accion/logout.php';
      });
    },
    calcularTotal() {
      this.total = this.seleccionados.reduce((acc, servicio) => acc + servicio.precio, 0);
    },
    sumarPuntos() {
      this.perfil.puntos = parseInt(this.perfil.puntos) + 10;
      localStorage.setItem("puntos", this.perfil.puntos);
    },
    prevSlide(tipo) {
      if (this.currentSlide[tipo] > 0) {
        this.currentSlide[tipo]--;
      }
    },
    nextSlide(tipo) {
      if (this.currentSlide[tipo] < this.servicios[tipo].length - 3) {
        this.currentSlide[tipo]++;
      }
    },
    autoSlide() {
      setInterval(() => {
        Object.keys(this.currentSlide).forEach(tipo => {
          this.nextSlide(tipo);
        });
      }, 3000);
    }
  },
  mounted() {
    if (this.autoSlide) this.autoSlide();
  }
}).mount('#app');
