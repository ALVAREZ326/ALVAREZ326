<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registro</title>
  <link rel="stylesheet" href="./CSS/styles.css">
</head>
<body>
  <div class="container">
    <div class="image-side">
      <img src="imagen/logo2.png" alt="Login Image">
    </div>
    <div class="form-side">
      <h2>Registro</h2>
      <form action="./accion/register_process.php" method="POST">
        <label>Nombre:</label>
        <input type="text" name="nombre" required>

        <label>Dirección:</label>
        <input type="text" name="direccion" required>

        <label>Teléfono:</label>
        <input type="tel" name="telefono" required>

        <label>Rol:</label>
        <select name="rol" required>
          <option disabled selected value="">Selecciona un rol</option>
          <option value="Cliente(a)">Cliente(a)</option>
          <option value="Administrador">Administrador</option>
        </select>

        <label>Email:</label>
        <input type="email" name="email" required>

        <label>Contraseña:</label>
        <input type="password" name="password" required>

        <button type="submit">Registrarse</button>
      </form>
      <div class="toggle-link">
        ¿Ya tienes cuenta? <a href="login.php">Inicia sesión</a>
      </div>
    </div>
  </div>
</body>
</html>
