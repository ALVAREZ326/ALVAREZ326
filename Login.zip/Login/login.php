<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Iniciar Sesión</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css"> <!-- Font Awesome para iconos -->
  <link rel="stylesheet" href="./CSS/styles.css"> <!-- Asegúrate de que esta ruta sea correcta -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      font-family: 'Arial', sans-serif;
      background: #f4f4f9;
      margin: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }
    .container {
      display: flex;
      max-width: 900px;
      width: 100%;
      box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
      border-radius: 10px;
      overflow: hidden;
    }
    .logo-side {
      flex: 1;
      background: #fff;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }
    .logo-side img {
      max-width: 100%;
      height: auto;
    }
    .form-side {
      flex: 1;
      background: #fff;
      padding: 40px;
      display: flex;
      flex-direction: column;
      justify-content: center;
    }
    .form-side h2 {
      text-align: center;
      color: #333;
      margin-bottom: 30px;
      font-size: 2em;
    }
    .form-side label {
      display: block;
      margin-bottom: 10px;
      font-weight: bold;
      color: #555;
    }
    .form-side input {
      width: 100%;
      padding: 10px 15px 10px 40px;
      margin-bottom: 20px;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 1em;
      box-sizing: border-box;
    }
    .form-side input:focus {
      outline: none;
      border-color: #c71585;
      box-shadow: 0 0 5px rgba(199, 21, 133, 0.3);
    }
    .input-icon {
      position: relative;
    }
    .input-icon i {
      position: absolute;
      left: 15px;
      top: 50%;
      transform: translateY(-50%);
      color: #888;
    }
    #email-input { padding-left: 40px; }
    #password-input { padding-left: 40px; }
    .form-side button {
      width: 100%;
      padding: 12px;
      background: #c71585;
      color: #fff;
      border: none;
      border-radius: 5px;
      font-size: 1.1em;
      cursor: pointer;
      transition: background 0.3s;
    }
    .form-side button:hover {
      background: #a31270;
    }
    .form-side p {
      text-align: center;
      margin-top: 20px;
      color: #666;
    }
    .form-side p a {
      color: #c71585;
      text-decoration: none;
    }
    .form-side p a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo-side">
      <img src="img/logo2.png" alt="Logo Salón Glamour Sensation">
    </div>
    <div class="form-side">
      <h2>Iniciar Sesión</h2>
      <form action="./accion/login_process.php" method="POST">
        <div class="input-icon">
          <i class="fas fa-envelope"></i>
          <input type="email" id="email-input" name="email" required placeholder="Correo electrónico">
        </div>
        <div class="input-icon">
          <i class="fas fa-lock"></i>
          <input type="password" id="password-input" name="password" required placeholder="Contraseña">
        </div>
        <button type="submit">Entrar</button>
      </form>
      <p>¿No tienes cuenta? <a href="./register.php">Regístrate</a></p>
    </div>
  </div>
</body>
</html>