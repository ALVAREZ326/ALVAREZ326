<?php
session_start();

if (!isset($_SESSION['usuario_id'])) {
    header("Location: ./login.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Bienvenida</title>
  <link rel="stylesheet" href="./CSS/styles.css">
</head>
<body>
  <div class="container">
    <div class="form-side">
      <h2>¡Bienvenido, <?php echo htmlspecialchars($_SESSION['nombre']); ?>!</h2>
      <p>Tu rol es: <?php echo htmlspecialchars($_SESSION['rol']); ?></p>
      <form action="./accion/logout.php" method="POST">
        <button type="submit">Cerrar sesión</button>
      </form>
    </div>
  </div>
</body>
</html>
