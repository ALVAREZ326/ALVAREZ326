<?php
session_start();
session_unset();
session_destroy();
echo "<script>localStorage.removeItem('usuarioLogueado'); localStorage.removeItem('puntos');</script>";
header("Location: ../index.php");
exit;
?>