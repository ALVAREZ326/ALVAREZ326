<?php
require 'db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = $_POST['nombre'];
    $direccion = $_POST['direccion'];
    $telefono = $_POST['telefono'];
    $rol = $_POST['rol'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Verificar si el correo ya existe
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
    $stmt->execute([$email]);

    if ($stmt->rowCount() > 0) {
        echo "El correo ya está registrado. <a href='../register.php'>Volver</a>";
        exit;
    }

    // Insertar nuevo usuario
    $stmt = $pdo->prepare("INSERT INTO usuarios (nombre, direccion, telefono, rol, email, password) VALUES (?, ?, ?, ?, ?, ?)");
    if ($stmt->execute([$nombre, $direccion, $telefono, $rol, $email, $password])) {
        echo "Registro exitoso. <a href='../login.php'>Inicia sesión aquí</a>";
    } else {
        echo "Error al registrar. <a href='../register.php'>Volver</a>";
    }
}
?>
