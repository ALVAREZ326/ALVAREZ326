<?php
session_start();
$isLoggedIn = isset($_SESSION['usuario_id']) ? 'true' : 'false';
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Salón de Belleza</title>
  <link rel="stylesheet" href="./CSS/styles-index.css">
  <script src="https://unpkg.com/vue@3/dist/vue.global.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
  <div id="app">
    <header class="encabezado">
      <h1>Salón de Belleza Glamour Sensation</h1>
      <img src="img/logo2.png" alt="Logo salon" />

      <nav class="menu">
        <a href="#quienes">Quiénes somos</a>
        <a href="#servicios">Servicios</a>
        <a href="#cita">Agendar Cita</a>
        <a href="#ubicacion">Ubicación</a>
        <a href="#perfil" v-if="usuarioLogueado">Mi Perfil</a>
        <a href="#" @click="cerrarSesion" v-if="usuarioLogueado">Cerrar sesión</a>
        <a href="/Login/login.php" v-if="!usuarioLogueado">Iniciar Sesión</a>
        <a href="/Login/register.php" v-if="!usuarioLogueado">Registrarse</a>
      </nav>
    </header>

    <main>
      <section id="quienes" class="card">
        <h2>¿Quiénes somos?</h2>
        <p>Somos <strong>Salón Glamour Sensation</strong>, un espacio dedicado a realzar tu belleza natural con servicios exclusivos y personalizados. Creemos que cada persona merece un tratamiento especial, por eso ofrecemos una experiencia única en cuidado capilar, maquillaje y uñas.</p>
        <p>Nuestro equipo está conformado por profesionales apasionados, siempre a la vanguardia de las últimas tendencias y técnicas para brindarte resultados espectaculares.</p>
        <p>En <strong>Glamour Sensation</strong>, combinamos calidad, innovación y calidez para que cada visita sea una experiencia inolvidable.</p>
        <img src="img/EquipoDeTrabajo.jpg" alt="Equipo del salón" class="img-quienes">
      </section>
      <section id="servicios" style="padding: 30px 20px; max-width: 1000px; margin: auto;">
        <h2>Servicios</h2>
        <div v-for="(categoria, tipo) in servicios" :key="tipo" class="card">
          <h3>{{ tipo }}</h3>
          <div class="carousel-container">
            <button @click="prevSlide(tipo)">◀</button>
            <div class="carousel">
              <div v-for="(servicio, index) in categoria" :key="index" class="servicio-item"
                   v-show="index >= currentSlide[tipo] && index < currentSlide[tipo] + 3">
                <img :src="servicio.imagen" :alt="servicio.nombre" class="servicio-img">
                <h4>{{ servicio.nombre }}</h4>
                <p>{{ servicio.descripcion }}</p>
                <strong>${{ servicio.precio }}</strong>
              </div>
            </div>
            <button @click="nextSlide(tipo)">▶</button>
          </div>
        </div>
      </section>
      <section id="cita">
        <h2>Agendar una Cita</h2>
        <div class="card">
          <label>Servicio:
            <select v-model="cita.servicio">
              <option disabled value="">Selecciona un servicio</option>
              <optgroup v-for="(categoria, tipo) in servicios" :label="tipo" :key="tipo">
                <option v-for="serv in categoria" :value="serv.nombre" :key="serv.nombre">
                  {{ serv.nombre }}
                </option>
              </optgroup>
            </select>
          </label><br><br>
          <label>Fecha: <input type="date" v-model="cita.fecha"></label><br><br>
          <label>Hora: <input type="time" v-model="cita.hora"></label><br><br>
          <button @click="confirmarCita">Confirmar Cita</button>
        </div>
      </section>

      <section id="ubicacion">
        <h2>¿Cómo llegar?</h2>
        <div class="card">
          <p>Estamos ubicados en Carrera Tercera, Quibdó, Chocó, Colombia.</p>
          <iframe
            src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d31847.979375487482!2d-76.65290574199079!3d5.690040283606957!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8e309b746d48f6d9%3A0x4aeb4aa47f95c12d!2sCarrera%203%2C%20Quibd%C3%B3%2C%20Choc%C3%B3%2C%20Colombia!5e0!3m2!1ses!2sco!4v1719174000000"
            width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy">
          </iframe>
          <a href="https://www.google.com/maps/dir//Carrera+3,+Quibd%C3%B3,+Choc%C3%B3,+Colombia" 
             target="_blank" class="btn-maps"> 
            Cómo llegar con Google Maps
          </a>
        </div>
      </section>

      <section id="calculadora">
        <h2>Calculadora de Costos</h2>
        <div class="card">
          <label v-for="(categoria, tipo) in servicios">
            <strong>{{ tipo }}</strong>
            <div v-for="servicio in categoria">
              <input type="checkbox" v-model="seleccionados" :value="servicio" @change="calcularTotal">
              {{ servicio.nombre }} - ${{ servicio.precio }}
            </div>
          </label>
          <h3>Total: ${{ total }}</h3>
          <div v-if="total > 0" class="pago-formulario">
            <h4>Completa tus datos para pagar:</h4>
            <label>
              Nombre:
              <input type="text" v-model="pago.nombre">
            </label><br><br>
            <label>
              Correo electrónico:
              <input type="email" v-model="pago.email">
            </label><br><br>
            <label>
              Método de pago:
              <select v-model="pago.metodo">
                <option disabled value="">Selecciona una opción</option>
                <option>Nequi</option>
                <option>Daviplata</option>
                <option>Transferencia bancaria</option>
              </select>
            </label><br><br>
            <button @click="realizarPago">Pagar ahora</button>
          </div>
        </div>
      </section>

      
    </main>

    <section id="galeria" class="galeria">
      <h2>Galería de Estilos</h2>
      <div class="galeria-grid">
        <div class="galeria-item" v-for="n in 7" :key="n">
          <img :src="'img/galeria' + n + '.jpg'" :alt="'Estilo ' + n">
        </div>
      </div>
    </section>

    <section id="testimonios">
      <h2>Testimonios</h2>
      <div class="card">
        <blockquote>
          "Excelente atención y resultados increíbles. ¡Recomendado 100%!"
          <footer>— Ana María</footer>
        </blockquote>
      </div>
    </section>

    <section>
      <div class="contact-info">
        <h3>Información de Contacto</h3>
        <p><strong>Dirección:</strong> Carrera Tercera, Quibdó, Chocó, Colombia.</p>
        <p><strong>Teléfono:</strong> +57 320-123-4567</p>
        <p><strong>Horarios:</strong> Lunes a sábado de 9:00 AM a 7:00 PM</p>
      </div>
    </section>

    <footer>
      <p>&copy; 2025 Salón Glamour Sensation💟. Todos los derechos reservados.</p>
    </footer>

    <a href="https://wa.me/+573226781908" class="whatsapp-float" target="_blank">
      <img src="img/whatsapp-logo.webp" alt="Chat en WhatsApp">
    </a>
  </div>

  <script src="app.js"></script>
  <script>
    const isLoggedIn = <?php echo $isLoggedIn; ?>;
    document.addEventListener('DOMContentLoaded', () => {
      localStorage.setItem('usuarioLogueado', isLoggedIn);
    });
  </script>
</body>
</html>